# Databricks notebook source
# MAGIC %md
# MAGIC # Reading & Writing
# MAGIC 1. Read from CSV files
# MAGIC 1. Read from JSON files
# MAGIC 1. Read from Parquet files
# MAGIC 1. Write DataFrame to files
# MAGIC 1. Write DataFrame to tables
# MAGIC 1. Write DataFrame to a Delta table

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Setup

# COMMAND ----------

# MAGIC %md
# MAGIC ### ![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) Read from CSV files
# MAGIC Read from CSV with DataFrameReader's `csv` method and the following options:
# MAGIC 
# MAGIC Tab separator, use first line as header, infer schema

# COMMAND ----------

from pyspark.sql.types import LongType, StringType, StructType, StructField

# COMMAND ----------

# MAGIC %md
# MAGIC spark.read.csv(path) is the syntax we need to use

# COMMAND ----------

usersCsvPath = "/mnt/training/ecommerce/users/users-500k.csv"

usersDF = (spark.read.csv(usersCsvPath))
display(usersDF)

# COMMAND ----------

# MAGIC %md
# MAGIC What is the problems here ? Separator and headers not defined

# COMMAND ----------

usersCsvPath = "/mnt/training/ecommerce/users/users-500k.csv"

usersDF = (spark.read
  .option("sep", "\t")
  .option("header", True)
  .option("inferSchema", True)
  .csv(usersCsvPath))

display(usersDF)

# COMMAND ----------

# MAGIC %md
# MAGIC ### ![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) Read from JSON files
# MAGIC 
# MAGIC Read from JSON with DataFrameReader's `json` method and the infer schema option

# COMMAND ----------

eventsJsonPath = "/mnt/training/ecommerce/events/events-500k.json"

eventsDF = (spark.read
  .option("inferSchema", True)
  .json(eventsJsonPath))

eventsDF.printSchema()

# COMMAND ----------

display(eventsDF)

# COMMAND ----------

# MAGIC %md
# MAGIC ### ![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) Read from parquet files

# COMMAND ----------

#List all the files 
dbutils.fs.ls("/mnt/training/ecommerce/events/")

# COMMAND ----------

#List all the files in the parquet file
dbutils.fs.ls("/mnt/training/ecommerce/events/events.parquet/")

# COMMAND ----------

ParquetDf = spark.read.parquet("/mnt/training/ecommerce/events/events.parquet")
display(ParquetDf)

# COMMAND ----------

# MAGIC %md
# MAGIC ### ![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) Write DataFrames to files
# MAGIC 
# MAGIC Write `usersDF` to parquet with DataFrameWriter's `parquet` method and 'csv' method and the following configurations:
# MAGIC 
# MAGIC We will call the functions notebook to help us

# COMMAND ----------

# MAGIC %run /FIC/Spark-Programming/Functions

# COMMAND ----------

usersOutputPath = workingDir + "/data.csv"

write_to_datalake_csv(usersDF, usersOutputPath)

# COMMAND ----------

usersOutputPath = workingDir + "/users.parquet"

(usersDF.write
  .option("compression", "snappy")
  .mode("overwrite")
  .parquet(usersOutputPath)
)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### ![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) Write DataFrames to tables
# MAGIC 
# MAGIC Write `eventsDF` to a table using the DataFrameWriter method `saveAsTable`
# MAGIC 
# MAGIC <img alt="Side Note" title="Side Note" style="vertical-align: text-bottom; position: relative; height:1.75em; top:0.05em; transform:rotate(15deg)" src="https://files.training.databricks.com/static/images/icon-note.webp"/> This creates a global table, unlike the local view created by the DataFrame method `createOrReplaceTempView`

# COMMAND ----------

eventsDF.write.mode("overwrite").saveAsTable("events_p")

# COMMAND ----------

# MAGIC %sql select * from events_p

# COMMAND ----------

# MAGIC %md
# MAGIC This table was saved in the database created for you in classroom setup. See database name printed below.

# COMMAND ----------

print(databaseName)

# COMMAND ----------

# MAGIC %md
# MAGIC ### ![Delta Lake Tiny Logo](https://pages.databricks.com/rs/094-YMS-629/images/delta-lake-tiny-logo.png) Best Practice: Write Results to a Delta Table
# MAGIC 
# MAGIC In almost all cases, the best practice is to use <a href="https://delta.io/" target="_blank">Delta Lake</a>, especially whenever the data will be referenced from a Databricks Workspace. Data in Delta tables is stored in Parquet format.
# MAGIC 
# MAGIC Write `eventsDF` to Delta with DataFrameWriter's `save` method and the following configurations:
# MAGIC 
# MAGIC Delta format, overwrite mode

# COMMAND ----------

eventsOutputPath = workingDir + "/delta/events"

(eventsDF.write
  .format("delta")
  .mode("overwrite")
  .save(eventsOutputPath)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## ![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) Ingesting Data Lab
# MAGIC 
# MAGIC Read in CSV files containing products data.
# MAGIC 1. Read with infer schema
# MAGIC 2. Write to Delta

# COMMAND ----------

# MAGIC %md
# MAGIC ### 1. Read with infer schema
# MAGIC 
# MAGIC - Create `productsDF` by reading from CSV files located in the filepath provided in the variable `productsCsvPath`
# MAGIC   - Configure options to use first line as header and infer schema

# COMMAND ----------

# TODO
productsCsvPath = "/mnt/training/ecommerce/products/products.csv"
productsDF = FILL_IN

productsDF.printSchema()

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ##### <img alt="Best Practice" title="Best Practice" style="vertical-align: text-bottom; position: relative; height:1.75em; top:0.3em" src="https://files.training.databricks.com/static/images/icon-blue-ribbon.svg"/> Check your work

# COMMAND ----------

assert(productsDF.count() == 12)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 2. Write to Delta
# MAGIC Write `productsDF` to the filepath provided in the variable `productsOutputPath`

# COMMAND ----------

display(productsDF)

# COMMAND ----------

# TODO
productsOutputPath = workingDir + "/delta/products"
productsDF.FILL_IN

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ##### <img alt="Best Practice" title="Best Practice" style="vertical-align: text-bottom; position: relative; height:1.75em; top:0.3em" src="https://files.training.databricks.com/static/images/icon-blue-ribbon.svg"/> Check your work

# COMMAND ----------

assert(len(dbutils.fs.ls(productsOutputPath)) == 5)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Clean up classroom

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Cleanup