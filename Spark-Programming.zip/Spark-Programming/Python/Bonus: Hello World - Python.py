# Databricks notebook source
# DBTITLE 1,The Hello World of Distributed Computing
# MAGIC %md #**WordCount Example**
# MAGIC 
# MAGIC ###Goal:  Determine the most popular words in a given text file using Python and SQL

# COMMAND ----------

# MAGIC %md ### ![](http://training.databricks.com/databricks_guide/downarrow.png) **Step 1**: Load text file from our [Hosted Datasets](https://docs.databricks.com/user-guide/faq/databricks-datasets.html).  **Shift-Enter Runs the code below.**

# COMMAND ----------

filePath = "dbfs:/databricks-datasets/SPARK_README.md" # path in Databricks File System
lines = sc.textFile(filePath) # read the file into the cluster
lines.take(10) # display first 10 lines in the file

# COMMAND ----------

# MAGIC %md ###![](http://training.databricks.com/databricks_guide/downarrow.png) **Step 2**:  Inspect the number of partitions (workers) used to store the dataset

# COMMAND ----------

numPartitions = lines.getNumPartitions() # get the number of partitions
print "Number of partitions (workers) storing the dataset = %d" % numPartitions

# COMMAND ----------

# MAGIC %md ###![](http://training.databricks.com/databricks_guide/downarrow.png) **Step 3**:  Split each line into a list of words separated by a space from the dataset

# COMMAND ----------

words = lines.flatMap(lambda x: x.split(' ')) # split each line into a list of words
words.take(10) # display the first 10 words

# COMMAND ----------

# MAGIC %md ###![](http://training.databricks.com/databricks_guide/downarrow.png) **Step 4**:  Filter the list of words to exclude common stop words

# COMMAND ----------

stopWords = ['','a','*','and','is','of','the','a'] # define the list of stop words
filteredWords = words.filter(lambda x: x.lower() not in stopWords) # filter the words
filteredWords.take(10) # display the first 10 filtered words

# COMMAND ----------

# MAGIC %md ###![](http://training.databricks.com/databricks_guide/downarrow.png) **Step 5**:  Cache the filtered dataset in memory to speed up future actions.

# COMMAND ----------

filteredWords.cache() # cache filtered dataset into memory across the cluster worker nodes

# COMMAND ----------

# MAGIC %md ###![](http://training.databricks.com/databricks_guide/downarrow.png) **Step 6**:  Transform filtered words into list of (word,1) tuples for WordCount

# COMMAND ----------

word1Tuples = filteredWords.map(lambda x: (x, 1)) # map the words into (word,1) tuples
word1Tuples.take(10) # display the (word,1) tuples

# COMMAND ----------

# MAGIC %md ###![](http://training.databricks.com/databricks_guide/downarrow.png) **Step 7**:  Aggregate the (word,1) tuples into (word,count) tuples

# COMMAND ----------

wordCountTuples = word1Tuples.reduceByKey(lambda x, y: x + y) # aggregate counts for each word
wordCountTuples.take(10) # display the first 10 (word,count) tuples

# COMMAND ----------

# MAGIC %md ###![](http://training.databricks.com/databricks_guide/downarrow.png) **Step 8**:  Display the top 10 (word,count) tuples by count

# COMMAND ----------

sortedWordCountTuples = wordCountTuples.top(10,key=lambda (x, y): y) # top 10 (word,count) tuples
for tuple in sortedWordCountTuples: # display the top 10 (word,count) tuples by count 
  print str(tuple)

# COMMAND ----------

# MAGIC %md ###![](http://training.databricks.com/databricks_guide/downarrow.png) **Step 9**:  Create a table from the (word,count) tuples

# COMMAND ----------

from pyspark.sql import Row # import the pyspark sql Row class
wordCountRows = wordCountTuples.map(lambda p: Row(word=p[0], count=int(p[1]))) # tuples -> Rows
wordCountRows.toDF().createOrReplaceTempView("word_count")

# COMMAND ----------

# MAGIC %md ###![](http://training.databricks.com/databricks_guide/downarrow.png) **Step 10**:  Use SQL to visualize the words with count >= 2

# COMMAND ----------

# MAGIC %sql 
# MAGIC SELECT word, count 
# MAGIC FROM word_count 
# MAGIC HAVING count >= 2
# MAGIC ORDER BY count DESC --use SQL to query words with count >= 2 descending in order