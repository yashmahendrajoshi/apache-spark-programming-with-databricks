# Databricks notebook source

classroomCleanup(username, moduleName, lessonName, True)
