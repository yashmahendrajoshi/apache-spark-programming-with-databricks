-- Databricks notebook source
-- MAGIC %md
-- MAGIC # Vacuum

-- COMMAND ----------

-- MAGIC %md
-- MAGIC `VACUUM` cleans up files associated with a table. There are different versions of this command for Delta and Apache Spark tables.

-- COMMAND ----------

CREATE TABLE students (name VARCHAR(64), address VARCHAR(64), student_id INT)
    USING DELTA PARTITIONED BY (student_id);

-- COMMAND ----------

INSERT OVERWRITE students VALUES
    ('Issac Newton', '123 Main Ave, Woolsthorpe', 3145),
    ('Ada Lovelace', '321 Main Ave, London', 2718);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC VACUUM will recursively vacuum directories associated with the Delta table and remove data files that are no longer in the latest state of the transaction log for the table and are older than a retention threshold. Files are deleted according to the time they have been logically removed from Delta’s transaction log + retention hours, not their modification timestamps on the storage system. The default threshold is 7 days. 

-- COMMAND ----------

VACUUM students RETAIN 168 HOURS DRY RUN

-- COMMAND ----------

-- MAGIC %md 
-- MAGIC The `RETAIN` argument  will set a threshold for how long files not required anymore should last. 
-- MAGIC 
-- MAGIC If you select a value less than 168 by default, Delta will warn

-- COMMAND ----------

VACUUM students RETAIN 167 HOURS DRY RUN

-- COMMAND ----------

-- MAGIC %md
-- MAGIC VACUUM takes an optional argument of DRY RUN. This will return a list of files to be deleted. This is a great idea to run!

-- COMMAND ----------

--- Clean up 
DROP TABLE students

-- COMMAND ----------

