# Databricks notebook source
# create a python list of tupels list_of_cars
list_of_cars = [(1,'Honda'),(2,'BMW'), (3,'Ford'),(4,'Toyota'),(5,'Skoda'),(6,'Mercedes'),(7,'Tata'),(8,'Audi')]

# create a list with columns of above data
columns = ['id','car_brands']

#Create dataframe using createDataFrame method
list_dataframe = spark.createDataFrame(list_of_cars, columns)

# Show the data from dataframe
list_dataframe.show()
