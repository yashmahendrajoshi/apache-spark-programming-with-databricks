# Databricks notebook source
# DBTITLE 1,Reading daily and weekly files
# Create a dataframe from a  daily csv file
def readdailycsv(path, date) :
   
  dataframe = spark.read.csv( "/mnt/prdadls/" + path + date + ".csv" , sep=";", header=True)
   
  return dataframe

# COMMAND ----------

# Create a dataframe from a daily dsv file
def readdailydsv(path, date) :
   
  dataframe = spark.read.csv("/mnt/prdadls/" + path + date + ".dsv" , sep=";", header=True)
   
  return dataframe

# COMMAND ----------

# Create a dataframe from a weekly file
def readweekly(path, file) :
  
  print("Reading {} ...".format(file)) 
  dataframe = spark.read.csv("/mnt/adls/" + path + file , sep=";", header=True)
   
  return dataframe

# COMMAND ----------

# Create a dataframe for creation of csv file from tmp file
def write_files_csv(dataframe,path,file_name):
  dataframe.repartition(1)\
    .write\
    .mode("overwrite")\
    .format("com.databricks.spark.csv")\
    .option("header", "true")\
    .option("delimiter", ";")\
    .save(PrmMountPoint+path + file_name +".tmp") 
  #Extract the csv file
  listFiles = dbutils.fs.ls(PrmMountPoint+path +file_name + ".tmp/")

  for subFiles in listFiles:
    if subFiles.name[-4:] == ".csv":
      dbutils.fs.cp (PrmMountPoint+path +file_name + ".tmp/" + subFiles.name,  PrmMountPoint+path +file_name +".csv")

  dbutils.fs.rm(PrmMountPoint+path+ file_name + ".tmp/", recurse=True)
  print("FILE WRITTEN")

# COMMAND ----------

# DBTITLE 1,Reading file lists
# Read files on Corporate ADLS with files list
def read_files(file_list, path):
  file_no = 1
  print("Reading {} ...".format(file_list[0]))
  df = spark.read.csv("/mnt/adls/"+ path + file_list[0], sep=";", header=True) 
  df = df.withColumn("file", func.lit(file_no))

  if len(file_list)>1:
    for files in file_list[1:]: 
      file_no +=1
      print("Reading {} ...".format(files))
      temp = spark.read.csv("/mnt/adls/"+ path + files, sep=";", header=True) 
      temp = temp.withColumn("file", func.lit(file_no))
      df = df.union(temp)
  return df

# COMMAND ----------

def read_files_csv_with_dt_file(file_list, path, sep=","):
  print("Reading {} ... ".format(file_list[0]))
  df = spark.read.csv(path + file_list[0], sep=sep, header=True) 
  file_date = file_list[0][0:8]
  df = df.withColumn("DT_FILE", func.lit(file_date))
  
  if len(file_list)>1:
    for files in file_list[1:]: 
      print("Reading {} ...".format(files))
      temp = spark.read.csv( path + files, sep=sep, header=True)
      file_date = files[0:8]
      temp = temp.withColumn("DT_FILE", func.lit(file_date))
      df = df.union(temp)
  return df

# COMMAND ----------

# Read files on Corporate ADLS with files list in PRD
def read_files_prd(file_list, path, sep=";"):
  file_no = 1
  print("Reading {} ...".format(file_list[0]))
  df = spark.read.csv("/mnt/prdadls/"+ path + file_list[0] + ".csv", sep=sep, header=True) 
  df = df.withColumn("file", func.lit(file_no))

  if len(file_list)>1:
    for files in file_list[1:]: 
      file_no +=1
      print("Reading {} ...".format(files))
      temp = spark.read.csv("/mnt/prdadls/"+ path + files + ".csv", sep=sep, header=True) 
      temp = temp.withColumn("file", func.lit(file_no))
      df = df.union(temp)
  return df

# COMMAND ----------

# # Read files on Corporate ADLS with files list in parquet format
# def read_files_parquet_with_dt_file(file_list, path):
#   file_no = 1
#   print("Reading {} ...".format(file_list[0]))
#   df = spark.read.parquet("/mnt/adls/"+ path + file_list[0]) 
#   file_date = file_list[0][0:8]
#   df = df.withColumn("DT_FILE", func.lit(file_date))

#   if len(file_list)>1:
#     for files in file_list[1:]: 
#       file_no +=1
#       print("Reading {} ...".format(files))
#       temp = spark.read.parquet("/mnt/adls/"+ path + files) 
#       temp = temp.withColumn("DT_FILE", func.lit(file_date))
#       df = df.union(temp)
#   return df

# COMMAND ----------

# Read files on Corporate ADLS with files list in parquet format
def read_files_parquet(file_list, path):
  file_no = 1
  print("Reading {} ...".format(file_list[0]))
  df = spark.read.parquet("/mnt/prdadls/"+ path + file_list[0]) 
  df = df.withColumn("file", func.lit(file_no))

  if len(file_list)>1:
    for files in file_list[1:]: 
      file_no +=1
      print("Reading {} ...".format(files))
      temp = spark.read.parquet("/mnt/prdadls/"+ path + files) 
      temp = temp.withColumn("file", func.lit(file_no))
      df = df.union(temp)
  return df

# COMMAND ----------

# DBTITLE 1,Converting Strings and Dates with different formats
#Convert Date to String with the format dd/mm/yyyy
def to_datestr(date):
  try:
    return date.strftime('%d/%m/%Y')
  except:
    return None

# COMMAND ----------

#STR to DATETIME (With Enter date format dd/mm/yyyy)
def to_datetime(datestr):
  try:
    return dt.datetime.strptime(datestr[:10],"%d/%m/%Y")
  except:
    return None

# COMMAND ----------

#STR to DATETIME (With Enter date format yyyy-mm-dd)
def to_datetime2(datestr):
  try:
    return dt.datetime.strptime(datestr[:10],"%Y-%m-%d")
  except:
    return None

# COMMAND ----------

#Convert string to float
def to_float(floatstr):
  try:
    if floatstr=="NA":
      return np.NaN
    else:
      return float(floatstr.strip("%"))
  except:
    return None

# COMMAND ----------

# DBTITLE 1,Date to month and String to Timestamp functions
#DATE TO MONTH  
def to_month(date):
  try:
    return date.replace(day=1)
  except:
    return None

# COMMAND ----------

#STR TO TIMESTAMP
def to_timestamp(datestr):
  try:
    return int(dt.datetime.strptime(datestr,"%d/%m/%Y").timestamp())
  except:
    return None

# COMMAND ----------

# DBTITLE 1,User defined functions for specific replacements, type conversions and time conversions
  #Remplace ',' by '.' and after convert the string value to float (Take a Column as parameter) Exmaple: commaToDot_udf(precision_recall["Proba"])
  
from pyspark.sql.types import DoubleType, DateType, StringType

commaToDot_udf = udf(lambda x : float(str(x).replace(',', '.')), DoubleType())


  #Convert string to float (Take a Column as parameter) Exmaple: to_datetime_udf(CUST_ORDERS["DT_LIV_TH_DLS"])
to_datetime_udf = udf(lambda datestr : to_datetime(datestr), DateType() )


  #Convert string to float (Take a Column as parameter) Exmaple: commaToDot_udf(CUST_ORDERS["DT_LIV_TH_DLS"])
to_datetime_udf2 = udf(lambda datestr : to_datetime2(datestr), DateType() )


  #Convert string to float (Take a Column as parameter)
to_float_udf = udf(lambda floatstr : to_float(floatstr), DoubleType() )


  #Convert Date to String (Take a Column as parameter)
to_datestr_udf = udf(lambda date: to_datestr(date), StringType() )

  #Convert date to the beginning of the month
to_month_udf = udf(lambda date : to_month(date), DateType() )


# COMMAND ----------

 #Time Delta Function (Take a Column as parameter)
timedelta_udf = udf(lambda date,delta : date + dt.timedelta(days=delta), DateType())

# COMMAND ----------

# DBTITLE 1,Datelist functions
# creating the range that allows a datelist to be defined based on no of jours
def datelist (endDate, jours):
    datelist = pd.date_range(start= endDate - timedelta(jours), end=endDate, freq='D').tolist()
    datelist = [ts.strftime('%Y%m%d') for ts in datelist]
    return datelist

# COMMAND ----------

#Creates a datelist based on timedelta period
def datelist_time (endDate, jours):
    datelist = pd.date_range(start= endDate - timedelta(jours), end=endDate, freq='D').tolist()
    return datelist

# COMMAND ----------

#Returns the previous day of a week
def previous_day(date, dayOfWeek):
    return func.date_sub(func.next_day(date, dayOfWeek), 7)  

#Returns a forecast date based on specified lag  
def forecast_date(date, lag):
  return date + dt.timedelta(lag*7)

forecast_date_udf = udf(lambda date,lag : forecast_date(date,lag), DateType())

# COMMAND ----------

# DBTITLE 1,Tables from file functions
# creating the function that directly converts path in ADLS into a temp table that can be queried using Spark
def fichier_to_table (env,path, table): 
  path = "adl://cdl" + env +"adlsweu.azuredatalakestore.net"+ path
  df =spark.read.csv(path, sep=";", header=True)
  df.registerTempTable(table)

# COMMAND ----------

# Creating a temp table that contains all the file name and size from a path
def tablefromfilelist(env, path, tablename) :
  path = "adl://cdl" + env +"adlsweu.azuredatalakestore.net"+ path
  print(path)
  df = dbutils.fs.ls(path)
  df = pd.DataFrame(df)
  sparkdf=sqlContext.createDataFrame(df)
  sparkdf.registerTempTable(tablename)

# COMMAND ----------

# Join betwen multiples data frames (Take in entry --> a list of dataframe and the columns on which to join)
def df_join(df_list, columns):
  try:
    res = df_list[0]
    for elem in df_list[1:]:
      res = res.join(elem, on = columns, how="outer")
    return res
  except:
    print("df_join error")
    return None

# COMMAND ----------

# DBTITLE 1,Parquet conversion functions
#convert parquet to csv format without deleting the parquet files
def convert_parquet_to_csv(fileprefix):
  df = spark.read.parquet(fileprefix)
  df.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").option("delimiter",";").save(fileprefix + ".dir" )
  listFiles = dbutils.fs.ls(fileprefix + ".dir/")
  for subFiles in listFiles:
    if subFiles.name[-4:] == ".csv":
      dbutils.fs.cp (fileprefix + ".dir/" + subFiles.name,  fileprefix+".csv")   
  dbutils.fs.rm(fileprefix + ".dir/", recurse=True)

# COMMAND ----------

# reads parquet file, returns as dataframe and registers temp table that can be queried using SQL
def read_parquet(path, file, table):
  df = spark.read.parquet(PrmMountPoint + path + file)
  sqlContext.registerDataFrameAsTable(df, table)
  return df


# COMMAND ----------

#reads and returns the count of lines in a parquet file
def count_parquet(path, file):
  df = spark.read.parquet(PrmMountPoint + path + file)
  count = df.count()
  return count

# COMMAND ----------

# DBTITLE 1,Memory Usage functions
#show memory used by a dataframe
def memory_usage(df):
    return(round(df.memory_usage(deep=True).sum() / 1024 ** 2, 2))

# COMMAND ----------

# DBTITLE 1,Lag functions
def lag_table(table, lag):
  Lag_table = table.select(["CAI", "DT_MONTH+"+str(lag), "DT_MONTH_MAX", "DMD_QTY"]).withColumn("DMD_QTY", func.lit('0')).withColumnRenamed("DT_MONTH+"+str(lag), "DT_MONTH")
  return Lag_table

# COMMAND ----------

def substract_week_lag(date, lag):
  return date - dt.timedelta(lag*7)

substract_week_lag_udf = udf(lambda date,lag : substract_week_lag(date,lag), DateType())

# COMMAND ----------

# DBTITLE 1,Check and remove double quotes from string
def remove_double_quotes_from_string_if_present(source_string):
  if str(source_string).startswith('"') and str(source_string).endswith('"'):
      return str(source_string)[1:-1]
  else:
      return str(source_string)

# COMMAND ----------

# DBTITLE 1,Check and delete directory from azure data lake gen1
def check_and_delete_zure_datalake_gen1_dir(dir_path):
  try:
    dbutils.fs.ls(dir_path)
    dbutils.fs.rm(dir_path, recurse=True)
    print(f'Deleted directory since it exists: {dir_path}')
  except:
    print(f'No need to delete directory since it does not exist: {dir_path}')

# COMMAND ----------

# DBTITLE 1,Casting columns
def cast_columns_as_int(df, columns):
   for col_name in columns:
    df = df.withColumn(col_name, df[col_name].cast("int"))
    return df 

# COMMAND ----------

def cast_columns_as_float(df, columns):
   for col_name in columns:
    df = df.withColumn(col_name, df[col_name].cast("float"))
    return df 

# COMMAND ----------

def cast_columns_as_date(df, columns):
   for col_name in columns:
    df = df.withColumn(col_name, df[col_name].cast("date"))
    return df 

# COMMAND ----------

# DBTITLE 1,Joining dataframes in pyspark
#Example CAI from table1 with PREDECESSOR from table2
def join_dataframes_with_different_columns(df1, df2, column1, column2, how):
  joined_dataframe = df1.join(df2, on = (df1[column1]==df2[column2]), how = how)
  joined_dataframe = joined_dataframe.dropDuplicates()
  return joined_dataframe

# COMMAND ----------

def join_dataframes(df1, df2, on, how):
  joined_dataframe = df1.join(df2, on = (on), how = how)
  joined_dataframe = joined_dataframe.dropDuplicates()
  return joined_dataframe

# COMMAND ----------

# DBTITLE 1,For loops
def custom_for_loop(iterable, action_to_do):
    iterator = iter(iterable)
    done_looping = False
    while not done_looping:
        try:
            item = next(iterator)
        except StopIteration:
            done_looping = True
        else:
            action_to_do(item)

# COMMAND ----------

# DBTITLE 1,Write to Datalake functions
def write_to_datalake_csv(df, fileprefix):
  df.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").option("delimiter",";").save(fileprefix + ".dir" )
  listFiles = dbutils.fs.ls(fileprefix + ".dir/")
  
  for subFiles in listFiles:
    if subFiles.name[-4:] == ".csv":
      dbutils.fs.cp (fileprefix + ".dir/" + subFiles.name,  fileprefix+".csv")
  
  dbutils.fs.rm(fileprefix + ".dir/", recurse=True)
  print("File has been written to datalake")
  
  
  
def write_to_datalake_csv_with_delimiter(df, fileprefix, delimiter):
  df.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").option("delimiter", delimiter).save(fileprefix + ".dir" )
  listFiles = dbutils.fs.ls(fileprefix + ".dir/")
  
  for subFiles in listFiles:
    if subFiles.name[-4:] == ".csv":
      dbutils.fs.cp (fileprefix + ".dir/" + subFiles.name,  fileprefix+".csv")
  
  dbutils.fs.rm(fileprefix + ".dir/", recurse=True)
  print("File has been written to datalake")
  
  
  
def write_to_datalake_csv_append(df, fileprefix):
  df.repartition(1).write.mode("append").format("com.databricks.spark.csv").option("header", "true").option("delimiter",";").save(fileprefix + ".dir" )
  listFiles = dbutils.fs.ls(fileprefix + ".dir/")
  
  for subFiles in listFiles:
    if subFiles.name[-4:] == ".csv":
      dbutils.fs.cp (fileprefix + ".dir/" + subFiles.name,  fileprefix+".csv")
  
  dbutils.fs.rm(fileprefix + ".dir/", recurse=True)
  print("File has been appended to datalake")
  
  
  
def write_to_datalake_parquet(df, path):
  df.repartition(100)\
    .write\
    .mode('overwrite')\
    .parquet(path)
  return



def write_to_datalake_parquet_with_partitions(df, path, num_partitions=-1):
  if num_partitions == -1:
    print(f"Writting without any repartition")
    df.write.mode('overwrite').parquet(path)
  else:
    print(f"Writting with repartition: {num_partitions}")
    num_partitions_int = int(num_partitions)
    df.repartition(num_partitions_int).write.mode('overwrite').parquet(path)

# COMMAND ----------

# DBTITLE 1,Auditing Functions
columns_to_select_from_audit_file = ['Audit_Date', 'Attribute_Name', 'Attribute_Value']

def get_audit_record(audit_date, attr_name, attr_val):
  audit_record = {}
  audit_record["Audit_Date"] = audit_date
  audit_record["Attribute_Name"] = attr_name
  audit_record["Attribute_Value"] = attr_val
  return audit_record

def get_schema_for_audit_file_record():
  schema = StructType(
    [
      StructField("Audit_Date", StringType(), True), 
      StructField("Attribute_Name", StringType(), True),
      StructField("Attribute_Value", StringType(), True)
    ]
  )
  return schema


def build_audit_records_list(audit_date, audit_records_dict):
  audit_records_list = []
  for attr_name, attr_value in audit_records_dict.items():
    audit_records_list.append(get_audit_record(audit_date, attr_name, attr_value))
  return audit_records_list


def build_audit_records_spark_df(audit_date, audit_records_dict):
  audit_records_list = build_audit_records_list(audit_date, audit_records_dict)
  schema_for_audit = get_schema_for_audit_file_record()
  audit_records_df = pd.DataFrame(audit_records_list)
  audit_records_df = audit_records_df.reindex(columns_to_select_from_audit_file, axis=1)
  audit_records_spark_df = spark.createDataFrame(audit_records_df, schema=schema_for_audit)
  return audit_records_spark_df


def generate_audit_records_spark_df(audit_date, audit_records_dict, audit_path):
  audit_records_spark_df = build_audit_records_spark_df(audit_date, audit_records_dict)
  return audit_records_spark_df

# COMMAND ----------

# Function to check if date string is as per format
def check_if_date_is_as_per_format(date_str, format):
  try:
    if date_str == None:
      return False
    else:
      dt.datetime.strptime(date_str, format)
      return True
  except ValueError:
    return False

# COMMAND ----------

#Function to get env from data factory name
def get_env_from_data_factory_name(data_factory_name):
  try:
    env_from_data_factory_name = data_factory_name[3:6]
    if env_from_data_factory_name == "dev":
      return "DEV"
    elif env_from_data_factory_name == "ind":
      return "INDUS"
    elif env_from_data_factory_name == "prd":
      return "PROD"
    else:
      return None
  except:
    return None

# COMMAND ----------

from pyspark.sql.functions import isnan, when, count, col

def display_null_values(df):
  df_null = df.select( [count(when(isnan(column), column)).alias(column) for column in df.columns])
  return df_null

# COMMAND ----------

# DBTITLE 1,Check if data lake path exists or not
def check_if_path_exists(path):
  try:
    dbutils.fs.ls(path)
    return True
  except:
    return False

# COMMAND ----------

def get_day_from_date(date_str, date_format):
  try:
    day_name_list= ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    day_number = dt.datetime.strptime(date_str, date_format).weekday()
    return day_name_list[day_number]
  except:
    return None

# COMMAND ----------

# DBTITLE 1,Apply single quote to every list element
def apply_sq_to_list(src_list):
  result_list =[]
  for element in src_list:
    result_list.append(f"'{element}'")
  return result_list

# COMMAND ----------

# DBTITLE 1,Compare two dates
def compare_dates(date1, date2, date_format):
  try:
    date1_obj = dt.datetime.strptime(date1, date_format)
    date2_obj = dt.datetime.strptime(date2, date_format)
    if date1_obj < date2_obj:
      return "-1"
    elif date1_obj == date2_obj:
      return "0"
    elif date1_obj > date2_obj:
      return "1"
    else:
      return None
  except:
    return None

# COMMAND ----------

#Function to read json file for particular region from CDL under DARIS folder
def get_json_config(json_file_path):
  json_file_path_to_read = "/dbfs" + json_file_path
  json_file = open(json_file_path_to_read)
  json_config = json.load(json_file,strict=False)
  return json_config

# COMMAND ----------

#Function to get all monday files from CDL Forecast folder
import datetime as dt
def mondayfile_ls(path: str):
    for x in dbutils.fs.ls(path):
      if x.name[15:-8]!='-yyyym':
        dt_stamp = dt.datetime(int(x.name[15:-8]), int(x.name[19:-6]), int(x.name[21:-4]))
        if dt_stamp.weekday()==0:
          yield x.name